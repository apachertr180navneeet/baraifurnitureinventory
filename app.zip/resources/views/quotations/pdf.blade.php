<!-- resources/views/quotations/pdf.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Quotation</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 14px; margin: 20px; }
        .header { margin-bottom: 20px; }
        .header h2 { margin: 0; }
        .header p { margin: 2px 0; color: #555; }
        .line { border-bottom: 1px solid #ccc; margin: 10px 0; }
        .item { display: flex; align-items: center; margin-bottom: 15px; }
        .item img { width: 80px; height: 80px; object-fit: cover; margin-right: 15px; border: 1px solid #ddd; padding: 5px; }
        .item-details { flex: 1; }
        .item-details p { margin: 2px 0; }
        .item-price { font-weight: bold; }
        .totals { margin-top: 20px; width: 100%; }
        .totals table { width: 100%; border-collapse: collapse; }
        .totals td { padding: 5px; }
        .totals .right { text-align: right; }
        .share-btn { display: block; margin-top: 30px; padding: 10px; background: #2d6cdf; color: #fff; text-align: center; text-decoration: none; border-radius: 5px; width: 120px; }
    </style>
</head>
<body>

<div class="header">
    <h2>{{ $user->name }}</h2>
    <p>{{ $user->phone }} | {{ $user->email }}</p>
    <p>{{ $user->address ?? 'Address not provided' }}</p>
</div>
<div class="line"></div>

@foreach($quotationRows as $row)
    <div class="item">
        <img src="{{ asset('storage/items/'.$row->item->image) }}" alt="{{ $row->item->name }}">
        <div class="item-details">
            <p><strong>{{ $row->item->name }}</strong></p>
            <p>Color: {{ $row->item->color ?? 'N/A' }}</p>
            <p>Qty: {{ $row->quantity }}</p>
        </div>
        <div class="item-price">
            Rs. {{ number_format($row->amount, 2) }}/-
        </div>
    </div>
@endforeach

<div class="totals">
    <table>
        <tr>
            <td>Sub Total</td>
            <td class="right">Rs. {{ number_format($totalAmount, 2) }}</td>
        </tr>
        <tr>
            <td>Sub Total</td>
            <td class="right">00.00</td>
        </tr>
        <tr>
            <td><strong>Grand Total</strong></td>
            <td class="right"><strong>Rs. {{ number_format($totalAmount, 2) }}</strong></td>
        </tr>
    </table>
</div>

<a href="#" class="share-btn">Share</a>

</body>
</html>
