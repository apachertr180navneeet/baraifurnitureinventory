@extends('web.layouts.app')
@section('content')
<section class="text-center">
    <div class="container pt-4 pb-4">
        <div class="row justify-content-center">
            <div class="col-lg-7 col-md-10 text-center">
                <div class="sec-heading center">
                    <h1 class="ft-bold">Home Page</h1>
                    <p class="mb-4 fs-6"></p>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('script')

@endsection