<footer class="bg-primary text-center text-white fixed-bottom">
    <div class="text-center p-3">
        © <script>document.write(new Date().getFullYear())</script> Copyright:
        <a class="text-white" href="javascript:void">{{ config('app.name') }}</a>
    </div>
    <!-- Copyright -->
</footer>