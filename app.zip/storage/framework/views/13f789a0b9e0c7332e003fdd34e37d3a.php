
<?php $__env->startSection('content'); ?>
<style>
    .thumb-image{
        height: 50px;
        width: 50px;
        border: 1px solid lightgray;
        padding: 1px;
    }
    .header-title{
        text-transform: capitalize;
        font-size:;
    }
</style>
<div class="container-fluid flex-grow-1 container-p-y">
    <h5 class="py-2 mb-2">
        <span class="text-primary fw-light">User Detail</span>
    </h5>
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h4 class="header-title">
                                <span>
                                <?php if(!empty($user->avatar) && file_exists(public_path('/').$user->avatar)): ?>
                                    <img src="<?php echo e(asset($user->avatar)); ?>" alt="User Image" class="thumb-image rounded-circle">
                                <?php else: ?>
                                    <img src="<?php echo e(asset("assets/admin/img/avatars/no-user.jpg")); ?>"  alt="User Image" class="thumb-image rounded-circle">
                                <?php endif; ?>
                                </span>
                                <span class="text-primary"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></span>
                            </h4>
                            <hr>
                            <div class="text-left mb-3">
                                <p class="text-muted"><strong>Email Address :</strong> <span class="ml-2"><?php echo e($user->email); ?></span></p>
                                <?php if($user->phone): ?>
                                <p class="text-muted"><strong>Phone Number :</strong> <span class="ml-2"><?php echo e($user->phone); ?></span></p>
                                <?php endif; ?>
                                <p class="text-muted"><strong>City:</strong> <span class="ml-2"><?php echo e($user->city); ?></span></p>
                                <p class="text-muted"><strong>State:</strong> <span class="ml-2"><?php echo e($user->state); ?></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel-setup-10\resources\views/admin/users/show.blade.php ENDPATH**/ ?>