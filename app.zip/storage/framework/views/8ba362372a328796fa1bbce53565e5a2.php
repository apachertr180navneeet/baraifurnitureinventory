<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
   
    <div class="container-fluid">
        
        <a class="navbar-brand mt-2 mt-lg-0" href="#">
            <h5 class="pt-1"><?php echo e(config('app.name')); ?></h5>
        </a>
        
        <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fas fa-bars"></i>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="d-flex align-items-center justify-content-start">
                
            </div>
            
        </div>
       
    </div>
   
</nav>
<?php /**PATH C:\xampp\htdocs\laravel_project\baraifurnitureinventory\resources\views/web/layouts/elements/header.blade.php ENDPATH**/ ?>