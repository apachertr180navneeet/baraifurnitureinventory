
<?php $__env->startSection('content'); ?>
<section class="text-center">
    <div class="container pt-4 pb-4">
        <div class="row justify-content-center">
            <div class="col-lg-7 col-md-10 text-center">
                <div class="sec-heading center">
                    <h1 class="ft-bold">Home Page</h1>
                    <p class="mb-4 fs-6"></p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_project\baraifurnitureinventory\resources\views/web/home/index.blade.php ENDPATH**/ ?>