<footer class="bg-primary text-center text-white fixed-bottom">
    <div class="text-center p-3">
        © <script>document.write(new Date().getFullYear())</script> Copyright:
        <a class="text-white" href="javascript:void"><?php echo e(config('app.name')); ?></a>
    </div>
    <!-- Copyright -->
</footer><?php /**PATH D:\xampp\htdocs\laravel-setup-10\resources\views/web/layouts/elements/footer.blade.php ENDPATH**/ ?>